close all;
clear all;
clc;

% Problem tanımı
fitfun = @KnapSack; % Fitness function
V_functions = @V_functions; % V transfer functions
transfer_functions = {1, 2, 3, 4}; % Transfer function types
max_iter = 5000; % Maximum iterations
N = 20; % Number of search agents
lb = 0; % Lower bound
ub = 1; % Upper bound


weights = {'ks_8a_w.xlsx', 'ks_8b_w.xlsx', 'ks_8c_w.xlsx', 'ks_8d_w.xlsx', 'ks_8e_w.xlsx'};
profits = {'ks_8a_p.xlsx', 'ks_8b_p.xlsx', 'ks_8c_p.xlsx', 'ks_8d_p.xlsx', 'ks_8e_p.xlsx'};
capacity = {'ks_8a_max_w.xlsx', 'ks_8b_max_w.xlsx', 'ks_8c_max_w.xlsx', 'ks_8d_max_w.xlsx', 'ks_8e_max_w.xlsx'};
optimum = {'ks_8a_o.xlsx', 'ks_8b_o.xlsx', 'ks_8c_o.xlsx', 'ks_8d_o.xlsx', 'ks_8e_o.xlsx'};

num_items = 8;


fitness_values = zeros(5, 4, 20); % Fitness değerlerini saklama
times = zeros(5, 4, 20); % Çalışma sürelerini saklama
convergence_curves = cell(5, 4, 20); % Yakınsama eğrilerini saklama
% Optimizasyon işlemi
for dataset_idx = 1:5
    disp(['Processing dataset ', num2str(dataset_idx)]);
    
    current_weights = weights{dataset_idx};
    current_profits = profits{dataset_idx};
    current_capacity = capacity{dataset_idx};
    current_optimum = xlsread(optimum{dataset_idx}); 
    
    for tf_idx = 1:4
        current_transfer = transfer_functions{tf_idx};
        disp(['Using transfer function ', num2str(tf_idx)]);
        
        figure; % Her bir transfer fonksiyonu için yeni bir grafik 
        hold on; % Aynı grafikte çizim
        
        for run = 1:20
            disp(['Run ', num2str(run), ' for dataset ', num2str(dataset_idx), ' using transfer function ', num2str(tf_idx)]);
            tic; % Zamanlayıcıyı başlat
            % Ensure all required parameters are passed to SO
            [Xfood, Xvalue, CNVG] = SO(N, max_iter, fitfun, num_items, lb, ub, current_weights, current_profits, current_capacity, V_functions, current_transfer);
            elapsedTime = toc; % Geçen süreyi hesapla
            times(dataset_idx, tf_idx, run) = elapsedTime; % Çalışma süresini sakla
            fitness_values(dataset_idx, tf_idx, run) = Xvalue(end); % Son fitness değerini sakla
            convergence_curves{dataset_idx, tf_idx, run} = CNVG; % Yakınsama eğrisini sakla
            % Yakınsama eğrisini çizin
            plot(CNVG);
        end
        
        hold off; % Aynı grafikte çizim yapmayı devre dışı bırak
        xlabel('Iteration');
        ylabel('Fitness Value');
        title(['Convergence Curves for Dataset ', num2str(dataset_idx), ' with Transfer Function ', num2str(tf_idx)]);
        legend(arrayfun(@(x) ['Run ' num2str(x)], 1:20, 'UniformOutput', false));
        
        % Box plot for fitness values
        figure;
        boxplot(reshape(fitness_values(dataset_idx, tf_idx, :), [], 1));
        xlabel('Runs');
        ylabel('Fitness Values');
        title(['Box Plot of Fitness Values for Dataset ', num2str(dataset_idx), ' with Transfer Function ', num2str(tf_idx)]);
        
        % Hesaplanan istatistikler
        mean_fitness = mean(fitness_values(dataset_idx, tf_idx, :));
        std_fitness = std(fitness_values(dataset_idx, tf_idx, :));
        median_fitness = median(fitness_values(dataset_idx, tf_idx, :));
        best_fitness = max(fitness_values(dataset_idx, tf_idx, :));
        worst_fitness = min(fitness_values(dataset_idx, tf_idx, :));
        gap = ((current_optimum - mean_fitness) / current_optimum) * 100; % GAP hesaplaması
        mean_time = mean(times(dataset_idx, tf_idx, :));

        % Rank (gap değerine göre sıralama)
        [~, sorted_indices] = sort(fitness_values(dataset_idx, tf_idx, :));
        ranked_fitness_values = fitness_values(dataset_idx, tf_idx, sorted_indices);

        % İstatistikleri ve rank değerlerini kaydetme
        statistics = {
            'Metric', 'Value';
            'Ortalama', mean_fitness;
            'Standart Sapma', std_fitness;
            'Medyan', median_fitness;
            'En iyi', best_fitness;
            'En kötü', worst_fitness;
            'GAP', gap;
            'Ortalama Zaman', mean_time;
        };

        rank_data = cell(21, 2); % 20 fitness değeri ve başlık için bir hücre dizisi
        rank_data(1,:) = {'Rank', 'Fitness Values'}; % Başlık
        for i = 1:length(ranked_fitness_values)
            rank_data{i+1, 1} = i;
            rank_data{i+1, 2} = ranked_fitness_values(i);
        end

        % Excel dosyalarına yazma
        stats_filename = sprintf('statistics_s%d_t%d.xlsx', dataset_idx, tf_idx);
        rank_filename = sprintf('rank_data_s%d_t%d.xlsx', dataset_idx, tf_idx);
        convergence_filename = sprintf('convergence_curves_s%d_t%d.xlsx', dataset_idx, tf_idx);

        writecell(statistics, stats_filename, 'Sheet', 'Statistics');
        writecell(rank_data, rank_filename, 'Sheet', 'Rank Data');

         % Yakınsama eğrilerini kaydetme
        for run = 1:20
            writematrix(convergence_curves{dataset_idx, tf_idx, run}, convergence_filename, 'Sheet', ['Run' num2str(run)]);
        end
    end

    % Tüm transfer fonksiyonlarının fitness değerlerini al
    fitness_values_S1 = reshape(fitness_values(dataset_idx, 1, :), [], 1); % S1 için fitness değerleri
    fitness_values_S2 = reshape(fitness_values(dataset_idx, 2, :), [], 1); % S2 için fitness değerleri
    fitness_values_S3 = reshape(fitness_values(dataset_idx, 3, :), [], 1); % S3 için fitness değerleri
    fitness_values_S4 = reshape(fitness_values(dataset_idx, 4, :), [], 1); % S4 için fitness değerleri

    % Wilcoxon Signed-Rank Testi uygulama
    [p_S1_S2, h_S1_S2] = signrank(fitness_values_S1, fitness_values_S2);
    [p_S1_S3, h_S1_S3] = signrank(fitness_values_S1, fitness_values_S3);
    [p_S1_S4, h_S1_S4] = signrank(fitness_values_S1, fitness_values_S4);

    % Sonuçları tabloya yazma
    results = {
        'Datasets', 'S1 ile S2 p değeri', 'S1 ile S2 h değeri', 'S1 ile S3 p değeri', 'S1 ile S3 h değeri', 'S1 ile S4 p değeri', 'S1 ile S4 h değeri';
        sprintf('Kp_8%d', dataset_idx), p_S1_S2, h_S1_S2, p_S1_S3, h_S1_S3, p_S1_S4, h_S1_S4;
    };

    % Excel dosyasına yazma
    results_filename = sprintf('wilcoxon_results_s%d.xlsx', dataset_idx);
    writecell(results, results_filename);
end