function fit = KnapSack(X, w, p, max_w, Dim)

    fit = zeros(1, 1); 
    w_top = 0;
    p_top = 0;
    
    % Toplam ağırlık her bir birey için
    for i = 1:Dim
        w_top = w_top + X(1, i) * w(1, i);
    end

    % Toplam fitness her bir birey için
    for i = 1:Dim
        p_top = p_top + X(1, i) * p(1, i);
    end

    % Maksimum ağırlık kontrolü
    if w_top <= max_w
        fit = p_top;
    else
        fit = 0;
    end

end