function binX = V_functions(X, version, num_items)
    binX = zeros(size(X));
    for i = 1:num_items
        switch version
            case 1
                
                transfer_value = abs(erf(sqrt(pi)/2 * X(i)));
            case 2
                
                transfer_value = abs(tanh(X(i)));
            case 3
                
                transfer_value = abs(X(i) / sqrt(1 + X(i)^2));
            case 4
                
                transfer_value = abs((2/pi) * atan((pi/2) * X(i)));
            otherwise
                error('Undefined transfer function version');
        end
        
        % Binarization step
        if transfer_value >= 0.5
            binX(i) = 1;
        else
            binX(i) = 0;
        end
    end
end