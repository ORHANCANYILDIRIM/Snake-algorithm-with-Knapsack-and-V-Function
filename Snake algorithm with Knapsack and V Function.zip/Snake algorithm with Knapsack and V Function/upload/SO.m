function [Xfood, Xvalue, CNVG] = SO(N, max_iter, fitfun, num_items, lb, ub, weights, profits, capacity, transfer,version)
    % Initialize parameters
    vec_flag = [1, -1];
    Threshold = 0.25;
    Thresold2 = 0.6;
    C1 = 0.5;
    C2 = 0.05;
    C3 = 2;
    X = lb + rand(N, num_items) * (ub - lb);
    fitness = zeros(1, N);

    %veri okuma
    w = xlsread(weights);
    p = xlsread(profits);
    max_w = xlsread(capacity); 
    
    % Initial fitness calculation
    for i = 1:N
        disp(['Original X(', num2str(i), '):']);
        disp(X(i,:));

        % Apply the transfer function to convert X(i,:) to binary
        X_bin = transfer(X(i,:), version, num_items);

        disp(['Binary X_bin(', num2str(i), '):']);
        disp(X_bin);

        fitness(i) = feval(fitfun, X_bin, w, p, max_w, num_items);
    end

    [GYbest, gbest] = max(fitness);
    Xfood = X(gbest,:);

    % Divide the swarm into two equal groups: males and females
    Nm = round(N / 2); % eq.(2&3)
    Nf = N - Nm;
    Xm = X(1:Nm, :);
    Xf = X(Nm + 1:N, :);
    fitness_m = fitness(1:Nm);
    fitness_f = fitness(Nm + 1:N);
    [fitnessBest_m, gbest1] = max(fitness_m);
    Xbest_m = Xm(gbest1,:);
    [fitnessBest_f, gbest2] = max(fitness_f);
    Xbest_f = Xf(gbest2,:);

    % Initialize convergence curve
    CNVG = zeros(1, max_iter);

    for t = 1:max_iter
        Temp = exp(-((t) / max_iter)); % eq.(4)
        Q = C1 * exp(((t - max_iter) / max_iter)); % eq.(5)
        if Q > 1
            Q = 1;
        end

        % Exploration Phase (no Food)
        if Q < Threshold
            for i = 1:Nm
                for j = 1:num_items
                    rand_leader_index = floor(Nm * rand() + 1);
                    X_randm = Xm(rand_leader_index, :);
                    flag_index = floor(2 * rand() + 1);
                    Flag = vec_flag(flag_index);
                    Am = exp(-fitness_m(rand_leader_index) / (fitness_m(i) + eps)); % eq.(7)
                    Xnewm(i, j) = X_randm(j) + Flag * C2 * Am * ((ub - lb) * rand + lb); % eq.(6)
                end
            end
            for i = 1:Nf
                for j = 1:num_items
                    rand_leader_index = floor(Nf * rand() + 1);
                    X_randf = Xf(rand_leader_index, :);
                    flag_index = floor(2 * rand() + 1);
                    Flag = vec_flag(flag_index);
                    Af = exp(-fitness_f(rand_leader_index) / (fitness_f(i) + eps)); % eq.(9)
                    Xnewf(i, j) = X_randf(j) + Flag * C2 * Af * ((ub - lb) * rand + lb); % eq.(8)
                end
            end
        else % Exploitation Phase (Food Exists)
            if Temp > Thresold2 % hot
                for i = 1:Nm
                    flag_index = floor(2 * rand() + 1);
                    Flag = vec_flag(flag_index);
                    for j = 1:num_items
                        Xnewm(i, j) = Xfood(j) + C3 * Flag * Temp * rand * (Xfood(j) - Xm(i, j)); 
                    end
                end
                for i = 1:Nf
                    flag_index = floor(2 * rand() + 1);
                    Flag = vec_flag(flag_index);
                    for j = 1:num_items
                        Xnewf(i, j) = Xfood(j) + Flag * C3 * Temp * rand * (Xfood(j) - Xf(i, j)); 
                    end
                end
            else % cold
                if rand > 0.6 % fight
                    for i = 1:Nm
                        for j = 1:num_items
                            FM = exp(-(fitnessBest_f) / (fitness_m(i) + eps)); 
                            Xnewm(i, j) = Xm(i, j) + C3 * FM * rand * (Q * Xbest_f(j) - Xm(i, j)); 
                        end
                    end
                    for i = 1:Nf
                        for j = 1:num_items
                            FF = exp(-(fitnessBest_m) / (fitness_f(i) + eps)); 
                            Xnewf(i, j) = Xf(i, j) + C3 * FF * rand * (Q * Xbest_m(j) - Xf(i, j)); 
                        end
                    end
                else % mating
                    for i = 1:Nm
                        for j = 1:num_items
                            Mm = exp(-fitness_f(i) / (fitness_m(i) + eps)); 
                            Xnewm(i, j) = Xm(i, j) + C3 * rand * Mm * (Q * Xf(i, j) - Xm(i, j)); 
                        end
                    end
                    for i = 1:Nf
                        for j = 1:num_items
                            Mf = exp(-fitness_m(i) / (fitness_f(i) + eps)); 
                            Xnewf(i, j) = Xf(i, j) + C3 * rand * Mf * (Q * Xm(i, j) - Xf(i, j)); 
                        end
                    end
                    flag_index = floor(2 * rand() + 1);
                    egg = vec_flag(flag_index);
                    if egg == 1
                        [GYworst, gworst] = min(fitness_m);
                        Xnewm(gworst,:) = lb + rand * (ub - lb); 
                        [GYworst, gworst] = min(fitness_f);
                        Xnewf(gworst,:) = lb + rand * (ub - lb);
                    end
                end
            end
        end

        for j = 1:Nm
            Flag4ub = Xnewm(j,:) > ub;
            Flag4lb = Xnewm(j,:) < lb;
            Xnewm(j,:) = (Xnewm(j,:) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;
        
            Xnewm_bin = transfer(Xnewm(j,:), 1, num_items);
            y = feval(fitfun, Xnewm_bin, w, p, max_w, num_items); 
            if y > fitness_m(j) 
                fitness_m(j) = y;
                Xm(j,:) = Xnewm(j,:);
            end
        end

        [Ybest1, gbest1] = max(fitness_m);

        for j = 1:Nf
            Flag4ub = Xnewf(j,:) > ub;
            Flag4lb = Xnewf(j,:) < lb;
            Xnewf(j,:) = (Xnewf(j,:) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;
        
            Xnewf_bin = transfer(Xnewf(j,:), 1, num_items);
            y = feval(fitfun, Xnewf_bin, w, p, max_w, num_items); 
            if y > fitness_f(j) 
                fitness_f(j) = y;
                Xf(j,:) = Xnewf(j,:);
            end
        end

        [Ybest2, gbest2] = max(fitness_f);

        if Ybest1 > fitnessBest_m
            Xbest_m = Xm(gbest1,:);
            fitnessBest_m = Ybest1;
        end
        if Ybest2 > fitnessBest_f
            Xbest_f = Xf(gbest2,:);
            fitnessBest_f = Ybest2;
        end
        if Ybest1 > Ybest2
            gbest_t(t) = max(Ybest1);
        else
            gbest_t(t) = max(Ybest2);
        end
        if fitnessBest_m > fitnessBest_f
            GYbest = fitnessBest_m;
            Xfood = Xbest_m;
        else
            GYbest = fitnessBest_f;
            Xfood = Xbest_f;
        end

        CNVG(t) = GYbest; 
    end

    Xvalue = gbest_t; 
end
